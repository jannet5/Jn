// KAPI-3 "gerçek kullanıcı gibi" testi: menü, SSS, linkler, klavye, reduced-motion, büyük metin
import { chromium } from 'playwright';
const url = process.argv[2] || 'http://localhost:4321/';
const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || (await import('fs')).readdirSync('/opt/pw-browsers').filter(d=>d.startsWith('chromium-')).sort().map(d=>`/opt/pw-browsers/${d}/chrome-linux/chrome`).pop() });
const sonuc = [];
const ok = (ad, kosul, ek = '') => sonuc.push(`${kosul ? 'GEÇTİ' : 'KALDI'} · ${ad}${ek ? ' · ' + ek : ''}`);
let p = await b.newPage({ viewport: { width: 375, height: 800 }, hasTouch: true, isMobile: true });
await p.goto(url, { waitUntil: 'networkidle' });
// mobil menü
await p.tap('.mnav summary');
ok('Mobil menü açılıyor', await p.locator('.mnav[open]').count() === 1);
await p.tap('.mnav-panel a[href="#paketler"]'); await p.waitForTimeout(900);
ok('Menü linki kapanıyor ve kaydırıyor', await p.locator('.mnav[open]').count() === 0 && await p.evaluate(() => Math.abs(document.getElementById('paketler').getBoundingClientRect().top) < 120));
// SSS
const d = p.locator('.faq details').first(); await d.locator('summary').tap();
ok('SSS açılıyor', await d.evaluate(e => e.open)); await d.locator('summary').tap(); ok('SSS kapanıyor', !(await d.evaluate(e => e.open)));
// linkler
const links = await p.$$eval('a', as => as.map(a => ({ h: a.getAttribute('href'), t: a.textContent.trim() })));
const kirik = links.filter(l => !l.h).length;
const anchors = links.filter(l => l.h && l.h.startsWith('#') && l.h.length > 1).map(l => l.h);
const eksik = await p.evaluate(a => a.filter(h => !document.querySelector(h)), anchors);
ok('Kırık çapa link yok', eksik.length === 0 && kirik === 0, eksik.join(','));
const wa = links.filter(l => l.h && l.h.startsWith('https://wa.me/'));
ok('WhatsApp linkleri config\'den', wa.length >= 4 && wa.every(l => l.h === wa[0].h), `${wa.length} adet`);
ok('Görünür yer tutucu metin yok', !(await p.evaluate(() => /XXXX|TODO|lorem/i.test(document.body.innerText))));
// dokunma alanları
const kucuk = await p.$$eval('a, summary, button', els => els.filter(e => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1 && r.height < 44 && getComputedStyle(e).display !== 'inline'; }).map(e => e.textContent.trim().slice(0, 30)));
ok('Dokunma alanı ≥44px (blok öğeler)', kucuk.length === 0, kucuk.join(' | '));
await p.close();
// klavye
p = await b.newPage({ viewport: { width: 1440, height: 900 } }); await p.goto(url);
await p.keyboard.press('Tab'); const ilk = await p.evaluate(() => document.activeElement.textContent.trim());
ok('İlk Tab: içeriğe geç linki', ilk === 'İçeriğe geç');
let odak = 0; for (let i = 0; i < 12; i++) { await p.keyboard.press('Tab'); const s = await p.evaluate(() => { const c = getComputedStyle(document.activeElement); return c.outlineStyle !== 'none' || c.boxShadow !== 'none'; }); if (s) odak++; }
ok('Odak halkası görünür', odak === 12, `${odak}/12`);
await p.close();
// reduced motion
p = await b.newPage({ viewport: { width: 375, height: 800 }, reducedMotion: 'reduce' }); await p.goto(url);
ok('Reduced-motion: başlık hemen görünür, defter dolu', await p.evaluate(() => getComputedStyle(document.querySelector('.hw > span')).transform === 'none' && getComputedStyle(document.querySelector('.ledger-line')).strokeDashoffset === '0px'));
await p.close();
// %200 metin
p = await b.newPage({ viewport: { width: 375, height: 800 } }); await p.goto(url);
await p.addStyleTag({ content: 'html{font-size:200%} body{font-size:32px}' });
ok('Büyük metinde yatay taşma yok', await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
await b.close();
console.log(sonuc.join('\n'));
